<?php 


$links = mysqli_connect("localhost","root","","phpcrud") or die("server error");

 ?>