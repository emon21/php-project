<?php
 
$links = mysqli_connect("localhost","root","","ecom2") or die("server error");
//mysqli_query($links,"create database links")or die ("database error");

//echo "Database connected";
 ?>
